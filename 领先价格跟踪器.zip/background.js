// 后台脚本 - 处理跨域请求
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "--") {
	return null;
  }
});